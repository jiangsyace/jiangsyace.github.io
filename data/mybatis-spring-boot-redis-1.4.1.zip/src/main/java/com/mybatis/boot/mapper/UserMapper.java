package com.mybatis.boot.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.mybatis.boot.model.User;

@Mapper
public interface UserMapper {

	public void add(User t);

	public void delete(int id);

	public void update(User t);

	public User load(int id);

	public String getUserName(int id);
	
	public List<User> list();
	
}