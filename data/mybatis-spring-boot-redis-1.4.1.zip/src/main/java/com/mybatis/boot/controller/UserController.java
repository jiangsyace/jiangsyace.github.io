package com.mybatis.boot.controller;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mybatis.boot.model.User;
import com.mybatis.boot.service.IUserService;

@Controller
@RequestMapping("/user")
public class UserController {

	@Resource(name = "userService")
	private IUserService userService;

	@RequestMapping("/list")
	public String list(Model model) {
		List<User> users = userService.list();
		model.addAttribute("users", users);
//		String username = userService.getUserName(2);
//		System.out.println("用户id为2的用户名是：" + username);
		return "user/list";
	}

	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public String add() {
		return "user/add";
	}

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public String add(User user, Model model) {
		userService.add(user);
		return "redirect:/user/list";
	}

}