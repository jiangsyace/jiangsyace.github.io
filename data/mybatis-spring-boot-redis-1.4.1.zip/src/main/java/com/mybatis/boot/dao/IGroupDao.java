package com.mybatis.boot.dao;

import java.util.List;

import com.mybatis.boot.model.Group;

public interface IGroupDao {

	public void add(Group group);

	public void delete(int id);

	public void update(Group group);

	public Group load(int id);

	public List<Group> list();

}