package com.mybatis.boot.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.mybatis.boot.dao.IGroupDao;
import com.mybatis.boot.model.Group;
import com.mybatis.boot.service.IGroupService;

@Service("groupService")
public class GroupService implements IGroupService {

	@Resource
	private IGroupDao groupDao;

	@Override
	public void add(Group group) {
		groupDao.add(group);
	}

	@Override
	public void delete(int id) {
		groupDao.delete(id);
	}

	@Override
	public void update(Group group) {
		groupDao.update(group);
	}

	@Override
	public Group load(int id) {
		return groupDao.load(id);
	}

	@Override
	public List<Group> list() {
		return groupDao.list();
	}

}