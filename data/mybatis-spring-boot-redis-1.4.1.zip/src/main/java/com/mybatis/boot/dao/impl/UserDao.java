package com.mybatis.boot.dao.impl;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Repository;

import com.mybatis.boot.dao.IUserDao;
import com.mybatis.boot.mapper.UserMapper;
import com.mybatis.boot.model.User;

@Repository("userDao")
public class UserDao extends BaseDao<User> implements IUserDao {

	@Override
	Class<?> getMapperClass() {
		return UserMapper.class;
	}

	@Override
	@Cacheable(cacheNames={"users"}, key="'user-'+#id")
	public String getUserName(int id) {
		System.out.println("没有缓存用户名，从数据库中获取的用户名");
		return sqlSession.selectOne(getTypeClassName("getUserName") , id);
	}

}