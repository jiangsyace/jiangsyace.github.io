package com.mybatis.boot.dao.impl;

import java.util.List;

import javax.annotation.Resource;

import org.apache.ibatis.session.SqlSession;

import com.mybatis.boot.dao.IBaseDao;

public abstract class BaseDao<T> implements IBaseDao<T> {
	
	@Resource
	protected SqlSession sqlSession;

	private String typeClassName;

	abstract Class<?> getMapperClass();

	public BaseDao() {
		typeClassName = getMapperClass().getName();
	}

	// @SuppressWarnings("unchecked")
	// private Class<T> getTypeClass() {
	// Type type = getClass().getGenericSuperclass();
	// if (type instanceof ParameterizedType) {
	// return (Class<T>) ((ParameterizedType) type)
	// .getActualTypeArguments()[0];
	// }
	// return null;
	// }
	
	public String getTypeClassName(String methodId){
		return typeClassName + "." + methodId ;
	}

	@Override
	public void add(T t) {
		sqlSession.insert(typeClassName + ".add", t);
	}

	@Override
	public void delete(int id) {
		sqlSession.delete(typeClassName + ".delete", id);
	}

	@Override
	public void update(T t) {
		sqlSession.update(typeClassName + ".update", t);
	}

	@Override
	public T load(int id) {
		return sqlSession.selectOne(typeClassName + ".load", id);
	}

	@Override
	public List<T> list() {
		return sqlSession.selectList(typeClassName + ".list");
	}

}