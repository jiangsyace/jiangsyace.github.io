package com.mybatis.boot.listener;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;
/**
 * 
 * @funcation 创建一个Listener，需要注入@WebListener以及实现ServletContextListener
 *	
 * @author LuTengQing
 * @create_date 2016年8月1日下午3:48:45
 */
@WebListener
public class MyListener implements ServletContextListener{

	@Override
	public void contextInitialized(ServletContextEvent sce) {
//		System.out.println("ServletContext初始化");
	}

	@Override
	public void contextDestroyed(ServletContextEvent sce) {
//		System.out.println("ServletContext销毁");
	}

}