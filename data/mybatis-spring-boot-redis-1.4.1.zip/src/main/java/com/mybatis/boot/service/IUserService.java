package com.mybatis.boot.service;

import java.util.List;

import com.mybatis.boot.model.User;

public interface IUserService {

	public void add(User user);

	public void delete(int id);

	public void update(User user);

	public User load(int id);
	
	public String getUserName(int id);

	public List<User> list();
}