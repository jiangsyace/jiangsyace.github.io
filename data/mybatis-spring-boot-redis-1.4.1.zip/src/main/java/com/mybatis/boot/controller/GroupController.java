package com.mybatis.boot.controller;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mybatis.boot.model.Group;
import com.mybatis.boot.service.IGroupService;

@Controller
@RequestMapping("/group")
public class GroupController {

	@Resource(name = "groupService")
	private IGroupService groupService;

	@RequestMapping("/list")
	public String list(Model model) {
		List<Group> users = groupService.list();
		model.addAttribute("groups", users);
		return "group/list";
	}

	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public String add() {
		return "group/add";
	}

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public String add(Group user, Model model) {
		groupService.add(user);
		return "redirect:/group/list";
	}

}