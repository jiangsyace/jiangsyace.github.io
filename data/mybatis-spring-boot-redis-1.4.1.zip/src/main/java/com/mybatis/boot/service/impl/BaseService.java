package com.mybatis.boot.service.impl;

import java.util.List;

import javax.annotation.Resource;

import com.mybatis.boot.dao.impl.BaseDao;
import com.mybatis.boot.service.IBaseService;

public abstract class BaseService<T> implements IBaseService<T> {

	@Resource
	protected BaseDao<T> baseDao;

	abstract void setBaseDao(BaseDao<T> baseDao);

	@Override
	public void add(T t) {
		// baseMapper.add(t);
		baseDao.add(t);
	}

	@Override
	public void delete(int id) {
		// baseMapper.delete(id);
		baseDao.delete(id);
	}

	@Override
	public void update(T t) {
		// baseMapper.update(t);
		baseDao.update(t);
	}

	@Override
	public T load(int id) {
		// return baseMapper.load(id);
		return baseDao.load(id);
	}

	@Override
	public List<T> list() {
		// return baseMapper.list();
		return baseDao.list();
	}

}