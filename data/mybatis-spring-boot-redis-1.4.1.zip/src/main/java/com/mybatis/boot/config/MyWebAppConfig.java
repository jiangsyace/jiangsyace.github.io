package com.mybatis.boot.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.mybatis.boot.interceptor.MyInterceptor;

@Configuration
public class MyWebAppConfig extends WebMvcConfigurerAdapter {

	@Override
	public void addInterceptors(InterceptorRegistry registry) {
//		 registry.addInterceptor(new MyInterceptor()).addPathPatterns("/*");
		 registry.addInterceptor(new MyInterceptor());
//		 System.out.println("初始化拦截器集合");
	}
	
}