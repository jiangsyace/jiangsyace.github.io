package com.mybatis.boot.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.mybatis.boot.model.Group;

@Mapper
public interface GroupMapper {

	public void add(Group group);

	public void delete(int id);

	public void update(Group group);

	public Group load(int id);

	public List<Group> list();

}