package com.mybatis.boot.listener;

import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

/**
 * 
 * @funcation 监控Session的创建和销毁
 * 
 * @author LuTengQing
 * @create_date 2016年8月1日下午3:48:29
 */
@WebListener
public class MySessionHttpListener implements HttpSessionListener {

	@Override
	public void sessionCreated(HttpSessionEvent se) {
//		System.out.println("Session创建");
	}

	@Override
	public void sessionDestroyed(HttpSessionEvent se) {
//		System.out.println("Session销毁");
	}

}