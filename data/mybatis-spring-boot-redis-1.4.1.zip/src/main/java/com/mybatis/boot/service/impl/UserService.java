package com.mybatis.boot.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.mybatis.boot.dao.IUserDao;
import com.mybatis.boot.model.User;
import com.mybatis.boot.service.IUserService;

@Service("userService")
public class UserService implements IUserService {

	@Resource
	private IUserDao userDao;

	@Override
	public void add(User user) {
		userDao.add(user);
	}

	@Override
	public void delete(int id) {
		userDao.delete(id);
	}

	@Override
	public void update(User user) {
		userDao.update(user);
	}

	@Override
	public User load(int id) {
		return userDao.load(id);
	}

	@Override
	public List<User> list() {
		return userDao.list();
	}

	@Override
	public String getUserName(int id) {
		return userDao.getUserName(id);
	}

}