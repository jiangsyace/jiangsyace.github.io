package com.mybatis.boot.dao.impl;

import org.springframework.stereotype.Repository;

import com.mybatis.boot.dao.IGroupDao;
import com.mybatis.boot.mapper.GroupMapper;
import com.mybatis.boot.model.Group;

@Repository("groupDao")
public class GroupDao extends BaseDao<Group> implements IGroupDao {

	@Override
	Class<?> getMapperClass() {
		return GroupMapper.class;
	}

}